package com.adguardlite.blocker

import android.app.Application

class AdGuardLiteApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
