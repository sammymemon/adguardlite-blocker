package com.adguardlite.blocker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.adguardlite.blocker.ui.screens.HomeScreen
import com.adguardlite.blocker.ui.screens.blocklist.BlocklistScreen
import com.adguardlite.blocker.ui.screens.apps.AppsScreen
import com.adguardlite.blocker.ui.screens.focus.FocusModeScreen
import com.adguardlite.blocker.ui.screens.SettingsScreen
import com.adguardlite.blocker.ui.screens.MoreScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Blocklist : Screen("blocklist")
    object Apps : Screen("apps")
    object FocusMode : Screen("focus_mode")
    object More : Screen("more")
    object Settings : Screen("settings")
}

@Composable
fun AdGuardLiteNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(Screen.Blocklist.route) {
            BlocklistScreen(navController = navController)
        }
        composable(Screen.Apps.route) {
            AppsScreen(navController = navController)
        }
        composable(Screen.FocusMode.route) {
            FocusModeScreen(navController = navController)
        }
        composable(Screen.More.route) {
            MoreScreen(navController = navController)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController)
        }
    }
}
