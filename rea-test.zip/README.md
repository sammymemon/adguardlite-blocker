# AdGuardLite - Android Content Blocker

An original Android content blocker app built with Kotlin and Jetpack Compose, inspired by the functionality of content blockers like BlockerHero.

## Features

- **Home Dashboard**: Shows blocker status with enable/disable toggle
- **Domain Management**: Add, edit, and remove blocked domains
- **Allowlist**: Manage websites you want to access
- **VPN-based Blocking**: Uses Android's VpnService for system-wide DNS blocking
- **Activity Summary**: Track locally processed block counts
- **Settings**: Privacy information, permissions, and reset options
- **Dark/Light Theme**: Supports system theme and manual theme switching
- **Local Storage**: All data stored locally with Room database - no data sent to remote servers

## Architecture

- **UI**: Jetpack Compose with Material 3
- **Architecture Pattern**: MVVM with ViewModels
- **Database**: Room for local persistence
- **Preferences**: DataStore for app settings
- **Navigation**: Navigation Compose
- **DI**: Manual dependency injection (simple approach)

## Building the App

### Prerequisites
- Android Studio Hedgehog or newer
- Android SDK API level 34
- JDK 17
- Kotlin 1.9.24

### Build Commands

```bash
# Clone and navigate to project
cd AdGuardLite

# Build debug APK
./gradlew assembleDebug

# Install on connected device
./gradlew installDebug

# Run unit tests
./gradlew test

# Run instrumented tests
./gradlew connectedAndroidTest
```

### APK Location
After building, the debug APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

## Important Notes About Blocking

### VPN Permission
This app uses Android's `VpnService` to provide system-wide blocking:
- When enabling blocking for the first time, Android will show a VPN permission dialog
- You must grant permission for blocking to work
- The VPN creates a local tunnel - **no network traffic leaves your device**
- A persistent notification is shown while the VPN is active
- The VPN can only be started by explicit user action (never automatically)

### Limitations
- **DNS-based blocking**: This implementation provides the VPN service structure. Full packet inspection and DNS filtering requires more complex implementation
- **Some apps may bypass VPN**: Apps using their own DNS resolvers or direct IP connections may not be blocked
- **Browser-specific**: System-wide blocking affects all apps using the VPN tunnel
- **Android restrictions**: Some Android versions have limitations on VPN behavior

### Privacy
- All blocked domains and settings are stored locally in a Room database
- No browsing history is collected or transmitted
- No personal information is sent to remote servers
- The VPN only runs locally on your device

## Usage

1. Open the app and tap "Enable Protection"
2. Grant VPN permission when prompted
3. Add domains to block in "Blocked Domains" screen
4. Use "Allowlist" for domains you want to always allow
5. Monitor blocking activity in the activity summary

## Testing

The app includes:
- Unit tests for domain models and repository logic
- Basic test structure for UI components

Run tests with `./gradlew test`.

## Troubleshooting

- **VPN won't connect**: Ensure VPN permission was granted. Try disabling and re-enabling
- **Apps not blocked**: Some apps bypass VPN. This is a limitation of VPN-based blocking
- **Notification missing**: Check notification permissions on Android 13+
- **App crashes**: Clear app data or reinstall

## License

MIT License
