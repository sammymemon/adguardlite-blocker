package com.adguardlite.blocker.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// BlockerHero inspired colors
val PrimaryBlue = Color(0xFF2196F3)
val PrimaryGreen = Color(0xFF4CAF50)
val Red = Color(0xFFF44336)
val Orange = Color(0xFFFF9800)
