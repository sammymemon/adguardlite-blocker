package com.adguardlite.blocker

import org.junit.Test
import org.junit.Assert.*

class DomainRepositoryTest {
    @Test
    fun domainCleaning_removesProtocols() {
        val domain = "https://www.example.com/path"
        val cleaned = domain.lowercase().trim().removePrefix("http://").removePrefix("https://").removePrefix("www.")
        assertEquals("example.com/path", cleaned)
    }

    @Test
    fun domainCleaning_handlesPlainDomain() {
        val domain = "EXAMPLE.COM"
        val cleaned = domain.lowercase().trim()
        assertEquals("example.com", cleaned)
    }
}
