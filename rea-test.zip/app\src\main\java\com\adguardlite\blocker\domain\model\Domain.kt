package com.adguardlite.blocker.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blocked_domains")
data class BlockedDomain(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val domain: String,
    val isEnabled: Boolean = true,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "allowlist_domains")
data class AllowlistDomain(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val domain: String,
    val addedAt: Long = System.currentTimeMillis()
)

data class BlockerState(
    val isBlockingEnabled: Boolean = false,
    val blockedCount: Int = 0
)
