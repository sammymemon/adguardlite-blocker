package com.adguardlite.blocker.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.adguardlite.blocker.ui.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(navController: NavController) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("More", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Screen.Home.route) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Screen.Blocklist.route) },
                    icon = { Icon(Icons.Default.Block, contentDescription = "Blocklist") },
                    label = { Text("Blocklist") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Screen.Apps.route) },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "Apps") },
                    label = { Text("Apps") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Screen.FocusMode.route) },
                    icon = { Icon(Icons.Default.Timer, contentDescription = "Focus") },
                    label = { Text("Focus") }
                )
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More") },
                    label = { Text("More") }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Premium Unlocked",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "All features available for free",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            
            ListItem(
                headlineContent = { Text("Whitelist") },
                leadingContent = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                modifier = Modifier.clickable { }
            )
            Divider()
            ListItem(
                headlineContent = { Text("Statistics") },
                leadingContent = { Icon(Icons.Default.BarChart, contentDescription = null) },
                modifier = Modifier.clickable { }
            )
            Divider()
            ListItem(
                headlineContent = { Text("Settings") },
                leadingContent = { Icon(Icons.Default.Settings, contentDescription = null) },
                modifier = Modifier.clickable { navController.navigate(Screen.Settings.route) }
            )
            Divider()
            ListItem(
                headlineContent = { Text("Help & Support") },
                leadingContent = { Icon(Icons.Default.Help, contentDescription = null) },
                modifier = Modifier.clickable { }
            )
            Divider()
            ListItem(
                headlineContent = { Text("About") },
                leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
                modifier = Modifier.clickable { }
            )
        }
    }
}
