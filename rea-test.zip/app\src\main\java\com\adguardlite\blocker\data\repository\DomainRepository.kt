package com.adguardlite.blocker.data.repository

import com.adguardlite.blocker.data.local.BlockedDomainDao
import com.adguardlite.blocker.domain.model.BlockedDomain
import com.adguardlite.blocker.domain.model.AllowlistDomain
import kotlinx.coroutines.flow.Flow

class DomainRepository(private val dao: BlockedDomainDao) {
    val blockedDomains: Flow<List<BlockedDomain>> = dao.getAllBlockedDomains()
    val enabledBlockedDomains: Flow<List<BlockedDomain>> = dao.getEnabledBlockedDomains()
    val allowlistDomains: Flow<List<AllowlistDomain>> = dao.getAllAllowlistDomains()

    suspend fun addBlockedDomain(domain: String) {
        val cleanDomain = domain.lowercase().trim().removePrefix("http://").removePrefix("https://").removePrefix("www.")
        if (cleanDomain.isNotEmpty()) {
            dao.insertBlockedDomain(BlockedDomain(domain = cleanDomain))
        }
    }

    suspend fun updateBlockedDomain(domain: BlockedDomain) {
        dao.updateBlockedDomain(domain)
    }

    suspend fun removeBlockedDomain(domain: BlockedDomain) {
        dao.deleteBlockedDomain(domain)
    }

    suspend fun addToAllowlist(domain: String) {
        val cleanDomain = domain.lowercase().trim().removePrefix("http://").removePrefix("https://").removePrefix("www.")
        if (cleanDomain.isNotEmpty()) {
            dao.insertAllowlistDomain(AllowlistDomain(domain = cleanDomain))
        }
    }

    suspend fun removeFromAllowlist(domain: AllowlistDomain) {
        dao.deleteAllowlistDomain(domain)
    }

    suspend fun clearAll() {
        dao.deleteAllBlockedDomains()
        dao.deleteAllAllowlistDomains()
    }
}
