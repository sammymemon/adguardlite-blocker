package com.adguardlite.blocker

import com.adguardlite.blocker.domain.model.BlockedDomain
import com.adguardlite.blocker.domain.model.AllowlistDomain
import org.junit.Test
import org.junit.Assert.*

class DomainModelTest {
    @Test
    fun blockedDomain_creation_isCorrect() {
        val domain = BlockedDomain(domain = "example.com")
        assertEquals("example.com", domain.domain)
        assertTrue(domain.isEnabled)
        assertTrue(domain.id == 0L)
    }

    @Test
    fun allowlistDomain_creation_isCorrect() {
        val domain = AllowlistDomain(domain = "trusted.com")
        assertEquals("trusted.com", domain.domain)
        assertTrue(domain.id == 0L)
    }
}
