package com.adguardlite.blocker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adguardlite.blocker.data.local.AppDatabase
import com.adguardlite.blocker.data.repository.DomainRepository
import com.adguardlite.blocker.domain.model.BlockedDomain
import com.adguardlite.blocker.domain.model.AllowlistDomain
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BlockerViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: DomainRepository
    val blockedDomains: StateFlow<List<BlockedDomain>>
    val allowlistDomains: StateFlow<List<AllowlistDomain>>

    private val _isBlockingEnabled = MutableStateFlow(false)
    val isBlockingEnabled: StateFlow<Boolean> = _isBlockingEnabled.asStateFlow()

    private val _blockedCountToday = MutableStateFlow(0)
    val blockedCountToday: StateFlow<Int> = _blockedCountToday.asStateFlow()

    init {
        val dao = AppDatabase.getDatabase(application).blockedDomainDao()
        repository = DomainRepository(dao)
        
        blockedDomains = repository.blockedDomains.stateInViewModelScope(emptyList())
        allowlistDomains = repository.allowlistDomains.stateInViewModelScope(emptyList())
    }

    private fun <T> kotlinx.coroutines.flow.Flow<T>.stateInViewModelScope(initialValue: T): StateFlow<T> {
        val state = MutableStateFlow(initialValue)
        viewModelScope.launch {
            this@stateInViewModelScope.collect { state.value = it }
        }
        return state
    }

    fun toggleBlocking() {
        _isBlockingEnabled.value = !_isBlockingEnabled.value
    }

    fun addBlockedDomain(domain: String) {
        viewModelScope.launch {
            repository.addBlockedDomain(domain)
        }
    }

    fun updateBlockedDomain(domain: BlockedDomain) {
        viewModelScope.launch {
            repository.updateBlockedDomain(domain)
        }
    }

    fun removeBlockedDomain(domain: BlockedDomain) {
        viewModelScope.launch {
            repository.removeBlockedDomain(domain)
        }
    }

    fun addToAllowlist(domain: String) {
        viewModelScope.launch {
            repository.addToAllowlist(domain)
        }
    }

    fun removeFromAllowlist(domain: AllowlistDomain) {
        viewModelScope.launch {
            repository.removeFromAllowlist(domain)
        }
    }

    fun resetAll() {
        viewModelScope.launch {
            repository.clearAll()
            _isBlockingEnabled.value = false
            _blockedCountToday.value = 0
        }
    }

    fun incrementBlockCount() {
        _blockedCountToday.value += 1
    }
}
