package com.adguardlite.blocker.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.adguardlite.blocker.domain.model.BlockedDomain
import com.adguardlite.blocker.domain.model.AllowlistDomain
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockedDomainDao {
    @Query("SELECT * FROM blocked_domains ORDER BY addedAt DESC")
    fun getAllBlockedDomains(): Flow<List<BlockedDomain>>

    @Query("SELECT * FROM blocked_domains WHERE isEnabled = 1")
    fun getEnabledBlockedDomains(): Flow<List<BlockedDomain>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlockedDomain(domain: BlockedDomain): Long

    @Update
    suspend fun updateBlockedDomain(domain: BlockedDomain)

    @Delete
    suspend fun deleteBlockedDomain(domain: BlockedDomain)

    @Query("DELETE FROM blocked_domains")
    suspend fun deleteAllBlockedDomains()

    // Allowlist
    @Query("SELECT * FROM allowlist_domains ORDER BY addedAt DESC")
    fun getAllAllowlistDomains(): Flow<List<AllowlistDomain>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllowlistDomain(domain: AllowlistDomain): Long

    @Delete
    suspend fun deleteAllowlistDomain(domain: AllowlistDomain)

    @Query("DELETE FROM allowlist_domains")
    suspend fun deleteAllAllowlistDomains()
}
